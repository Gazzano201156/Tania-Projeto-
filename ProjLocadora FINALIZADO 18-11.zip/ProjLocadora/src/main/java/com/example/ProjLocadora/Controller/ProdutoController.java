package com.example.ProjLocadora.Controller;


import com.example.ProjLocadora.Model.ModelCliente;
import com.example.ProjLocadora.Model.ModelProduto;
import com.example.ProjLocadora.Repository.RepositoryCliente;
import com.example.ProjLocadora.Repository.RepositoryProduto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping (value = "/apiProduto")
public class ProdutoController {



    @Autowired
    RepositoryProduto repoProd;


    @GetMapping (value="/todos")
    public List<ModelProduto> buscarTodos()
    {
        return  repoProd.findAll();
    }



    /*Inserir, Excluir e Atualizar*/

    @PostMapping("/inserirProduto")
    public void inserirProduto(@RequestBody ModelProduto prod){

        repoProd.save(prod);
    }

    @PutMapping ("/atualizar")
    public void atuProduto(@RequestBody ModelProduto prod){
        repoProd.save(prod);
    }

    @DeleteMapping ("/removerProduto")
    public void deleteProduto(@RequestBody ModelProduto prod){
        repoProd.delete(prod);
    }


    @GetMapping("/produtocodigo/{codigo}")
    public Optional<ModelProduto> buscarPorCodigo
            (@PathVariable(value="codigo") int codigo)
    {
        return repoProd.findById(codigo);
    }


    @GetMapping("/produtodescricao/{descricao}")
    public List<ModelProduto> buscarPorDescricao
            (@PathVariable(value="descricao") String descricao)
    {
        return repoProd.findByDescricao(descricao);
    }


    @GetMapping("/produtopreco/{preco}")
    public List<ModelProduto> buscarPorPreco
            (@PathVariable(value="preco") Integer preco)
    {
        return repoProd.findByValor(preco);
    }

    @GetMapping("/produtomarca/{marca}")
    public List<ModelProduto> buscarPorMarca
            (@PathVariable(value="marca") String marca)
    {
        return repoProd.findByMarca(marca);
    }

    @GetMapping("/descricaoMarca/{descricao}/{marca}")
    public List<ModelProduto> listarDescricaoMarca
            (@PathVariable (value="descricao") String descricao,
             @PathVariable (value="marca") String marca)
    {
        return repoProd.findByDescriMarca(descricao, marca);
    }


    @GetMapping ("/marcaEspec/{marca}")
    public List<ModelProduto> listarPorMarcaEspec(@PathVariable(value="marca") String marca)
    {
        return repoProd.findByMarcaEspec(marca);
    }

    @GetMapping ("/precoMaior/{valor}")
    public List<ModelProduto> listarPorPrecoMaior
            (@PathVariable(value="valor") int valor)
    {
        return repoProd.findByPrecoMaior(valor);
    }


    @GetMapping ("/precoMenor/{valor}")
    public List<ModelProduto> listarPorPrecoMenor
            (@PathVariable(value="valor") int valor)
    {
        return repoProd.findByPrecoMenor(valor);
    }

    @GetMapping("/inicialDescricao/{descricao}")
    public List<ModelProduto> listDescricao(@PathVariable(value="descricao") String descricao) {
        return repoProd.findByDescricao(descricao);
    }

   /* @GetMapping("/descDescPrec/{descricao}/{preco}")
    public List<ModelProduto> listDescPrecMenor(@)*/

    @GetMapping("/descricaoValor/{descricao}/{valor}")
    public List<ModelProduto> listarDescricaoValor(@PathVariable (value="descricao") String descricao, @PathVariable (value="valor") int valor)
    {
        return repoProd.findByDescricaoValor(descricao,valor);
    }





}

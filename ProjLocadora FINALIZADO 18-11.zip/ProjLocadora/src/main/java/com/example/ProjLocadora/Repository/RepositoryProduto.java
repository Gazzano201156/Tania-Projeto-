package com.example.ProjLocadora.Repository;

import com.example.ProjLocadora.Model.ModelCliente;
import com.example.ProjLocadora.Model.ModelProduto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.ui.Model;

import java.util.List;

public interface RepositoryProduto extends JpaRepository <ModelProduto, Integer> {
    @Query(value="select p from ModelProduto p where p.descricao like %?1%")
    List<ModelProduto> findByDescricao(String descricao);
    @Query(value = "select p from ModelProduto p where p.marca like %?1%")
    List<ModelProduto> findByMarcaEspec(String marca);

    @Query (value = "select p from ModelProduto p where p.descricao like %?1% and p.marca like %?2%")
    List<ModelProduto> findByDescriMarca(String descricao, String marca);


    @Query (value = "select p from ModelProduto p where p.valor > ?1")
    List<ModelProduto> findByPrecoMaior(int valor);

    @Query (value = "select p from ModelProduto p where p.valor < ?1")
    List<ModelProduto> findByPrecoMenor(int valor);

    List<ModelProduto> findByMarca(String marca);



    List<ModelProduto> findByValor(Integer valor);


    @Query (value = "select p from ModelProduto p where p.descricao like %?1% and p.valor < ?2")
    List<ModelProduto> findByDescricaoValor(String descricao, int valor);
}

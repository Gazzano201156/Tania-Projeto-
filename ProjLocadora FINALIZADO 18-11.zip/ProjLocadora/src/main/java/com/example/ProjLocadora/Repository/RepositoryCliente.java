package com.example.ProjLocadora.Repository;

import com.example.ProjLocadora.Controller.ClienteController;
import com.example.ProjLocadora.Model.ModelCliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface RepositoryCliente extends JpaRepository <ModelCliente,Integer> {


    public List<ModelCliente> findByNome (String nome);


    List<ModelCliente> findByEmail(String email);

    @Query (value = "select c from ModelCliente c where c.email like ?1% and c.nome like ?2%")
    List<ModelCliente> findByEmailNome(String email, String nome);
    @Query (value = "select c from ModelCliente c where c.nome like %?1%")
    List<String> findByNomeEspec(String nome);


    @Query (value = "select c from ModelCliente c where c.codigo > ?1")
    List<ModelCliente> findByCodigoMaior (int codigo);


}

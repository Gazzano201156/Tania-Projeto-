package com.example.ProjLocadora.Controller;

import com.example.ProjLocadora.Model.ModelCliente;
import com.example.ProjLocadora.Repository.RepositoryCliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping (value = "/apiCliente")
public class ClienteController {



    @Autowired
    RepositoryCliente repoCli;




    /* Inserir excluir atualizar*/

    @PostMapping("/inserirCliente")
    public void inserirCliente(@RequestBody ModelCliente cli){

        repoCli.save(cli);
    }

    @DeleteMapping ("/remover")
    public void deleteCliente(@RequestBody ModelCliente cli){
        repoCli.delete(cli);
    }

    @PutMapping ("/atualizar")
    public void atuCliente(@RequestBody ModelCliente cli){
        repoCli.save(cli);
    }




    @GetMapping("/todos")
    public List<ModelCliente> buscarTodos() {
        return repoCli.findAll();
    }

    @GetMapping("/clientecod/{codigo}")
    public Optional<ModelCliente> buscarPorCodigo
            (@PathVariable(value="codigo") int codigo)
    {
        return repoCli.findById(codigo);
    }


    @GetMapping("/clientenome/{nome}")
    public List<ModelCliente> buscarPorNome
            (@PathVariable(value="nome") String nome)
    {
        return repoCli.findByNome(nome);
    }


    @GetMapping("/findEmail/{email}")
    public List< ModelCliente> findByEmail(@PathVariable("email") String email){
        return repoCli.findByEmail(email);
    }


    @GetMapping ("/EmailNome/{email}/{nome}")
    public List<ModelCliente> listarEmailNome
            (@PathVariable (value="email") String email,
             @PathVariable (value="nome") String nome)
    {
        return repoCli.findByEmailNome(email, nome);
    }



    @GetMapping ("/nomeEspec/{nome}")
    public List<String> listarPorNomeEspec
            (@PathVariable(value="nome") String nome)
    {
        return repoCli.findByNomeEspec(nome);
    }

    @GetMapping ("/codigoMaior/{codigo}")
    public List<ModelCliente> listarPorCodigoMaior
            (@PathVariable(value="codigo") int codigo)
    {
        return repoCli.findByCodigoMaior(codigo);
    }

    @GetMapping("/inicialEmail/{email}")
    public List<ModelCliente> listEmail(@PathVariable("email") String email) {
        return repoCli.findByEmail(email);
    }





}

package com.example.ProjLocadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjLocadoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjLocadoraApplication.class, args);
	}

}
